package org.main;

import org.apache.commons.cli.*;

import java.util.List;

public class Main {
    public static void main(String[] args) throws ParseException {
        List<String> files = parseCommandLineArgs(args);

        System.out.println("Hello World");
    }

    // parse the command line arguments and return all non arg arguments as an ArrayList
    private static List<String> parseCommandLineArgs(String[] args) throws ParseException {
        Options options = new Options();

        // add test option
        options.addOption("t", "test", false, "test");

        CommandLineParser commandLineParser = new DefaultParser();
        CommandLine commandLine = commandLineParser.parse(options, args);

        if(commandLine.hasOption("t")) {
            CommandLineOptions.get().setTest(true);
        }

        // all non matched things get returned
        return commandLine.getArgList();
    }
}
